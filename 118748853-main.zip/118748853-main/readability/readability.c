#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);

int main(void)
{
    //Prompt user for text string
    string text = get_string("Text: ");

    //Calculate letters
    int letters = count_letters(text);

    //Calculate words
    int words = count_words(text);

    //Calculate sentences
    int sentences = count_sentences(text);

    // Calculating grade level using Coleman-Liau index
    float L = (float)letters / words * 100;
    float S = (float)sentences / words * 100;
    int grade_level = round(0.0588 * L - 0.296 * S - 15.8);

    if (grade_level < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (grade_level > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Grade %i\n", grade_level);
    }

}

int count_letters(string text)
{
    int len = strlen(text);
    int counter = 0;

    for (int i = 0; i < len; i++)
    {
        if (isalpha(text[i]) != 0)
        {
            counter++;
        }

    }
    return counter;
}

int count_words(string text)
{
    int len = strlen(text);
    int counter = 1;

    for (int i = 0; i < len; i++)
    {
        if (text[i] == ' ')
        {
            counter++;
        }

    }
    return counter;
}

int count_sentences(string text)
{
    int len = strlen(text);
    int counter = 0;

    for (int i = 0; i < len; i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            counter++;
        }

    }
    return counter;

}
