#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

bool only_digits(string key);
char rotate(char p, int k);


int main(int argc, string argv[])
{
    string key = argv[1];

    //ensure user enters exactly one command line argument
    if (argc != 2 || !only_digits(key))
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    int k = atoi(key);
    string plaintext = get_string("Plaintext:  ");
    int len = strlen(plaintext);
    char ciphertext[len];
    for (int i = 0; i < len; i++)
    {
        ciphertext[i] = rotate(plaintext[i], k);
    }
    ciphertext[len] = '\0';
    printf("ciphertext: %s\n", ciphertext);
    return 0;
}

//Check if key is a digit
bool only_digits(string key)
{
    int len = strlen(key);
    for (int i = 0; i < len; i++)
    {
        if (!isdigit(key[i]))
        {
            return false;
        }
    }
    return true;
}

char rotate(char pi, int k)
{
    char ci;
    if (isupper(pi))
    {
        ci = (pi - 65 + k) % 26 + 65;
    }
    else if (islower(pi))
    {
        ci = (pi - 97 + k) % 26 + 97;
    }
    else
    {
        return pi;
    }
    return ci;
}










